package com.example.unit_converter;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText inputValue = findViewById(R.id.inputvalues);
    Spinner categorySpinner, conversionSpinner;
    Button convertBtn;
    TextView resultText;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        categorySpinner = findViewById(R.id.categoryspinner);
        conversionSpinner = findViewById(R.id.conversionSpinner);
        convertBtn = findViewById(R.id.convertBtn);
        resultText = findViewById(R.id.resultText);

        String[] categories = {"Length", "Weight", "Temperature"};

        ArrayAdapter<String> categoryAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                categories
        );

        categorySpinner.setAdapter(categoryAdapter);

        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String selectedCategory = categorySpinner.getSelectedItem().toString();
                String[] conversions;

                if (selectedCategory.equals("Length")) {
                    conversions = new String[]{"Kilometer to Meter", "Meter to Kilometer"};
                } else if (selectedCategory.equals("Weight")) {
                    conversions = new String[]{"Kilogram to Gram", "Gram to Kilogram"};
                } else {
                    conversions = new String[]{"Celsius to Fahrenheit", "Fahrenheit to Celsius"};
                }

                ArrayAdapter<String> conversionAdapter = new ArrayAdapter<>(
                        MainActivity.this,
                        android.R.layout.simple_spinner_dropdown_item,
                        conversions
                );

                conversionSpinner.setAdapter(conversionAdapter);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        convertBtn.setOnClickListener(v -> {

            if (inputValue.getText().toString().isEmpty()) {
                Toast.makeText(MainActivity.this,
                        "Please enter a value", Toast.LENGTH_SHORT).show();
                return;
            }

            double value = Double.parseDouble(inputValue.getText().toString());
            String conversionType = conversionSpinner.getSelectedItem().toString();
            double result;

            switch (conversionType) {

                case "Kilometer to Meter":
                    result = value * 1000;
                    resultText.setText("Result: " + result + " meters");
                    break;

                case "Meter to Kilometer":
                    result = value / 1000;
                    resultText.setText("Result: " + result + " kilometers");
                    break;

                case "Kilogram to Gram":
                    result = value * 1000;
                    resultText.setText("Result: " + result + " grams");
                    break;

                case "Gram to Kilogram":
                    result = value / 1000;
                    resultText.setText("Result: " + result + " kilograms");
                    break;

                case "Celsius to Fahrenheit":
                    result = (value * 9 / 5) + 32;
                    resultText.setText("Result: " + result + " °F");
                    break;

                case "Fahrenheit to Celsius":
                    result = (value - 32) * 5 / 9;
                    resultText.setText("Result: " + result + " °C");
                    break;
            }
        });
    }
}
